import { StartHourPipe } from './start-hour-pipe';

describe('StartHourPipe', () => {
  it('create an instance', () => {
    const pipe = new StartHourPipe();
    expect(pipe).toBeTruthy();
  });
});
