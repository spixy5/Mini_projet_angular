export interface PromoCode {
id: number;
  code: string;
  percentage: number;
  used: boolean;
}
