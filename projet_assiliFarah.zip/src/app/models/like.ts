export interface Like {
     user_id: number;
  museum_id: number;
}
